#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <SDL.h>
#include "drawline.h"
#include "triangle.h"
#include "list.h"
#include "teapot_data.h"
#include "sphere_data.h"
#include "object.h"

void clear_screen(SDL_Surface *surface);
void bouncing_balls(SDL_Window *window);

int main(void)
{
    const size_t bufsize = 100;
    srand(time(NULL));
    
    // Change the screen width and height to your own liking
    const int screen_w = 1600;
    const int screen_h = 900;

    char errmsg[bufsize];
    SDL_Window *window;

    // Initialize SDL
    if (SDL_Init(SDL_INIT_VIDEO) < -1) {
        snprintf(errmsg, bufsize, "Unable to initialize SDL.");
        goto error;
    }
    
    // Create a 1600x900 window
    window = SDL_CreateWindow("The Amazing Bouncing Balls",
                              SDL_WINDOWPOS_UNDEFINED,
                              SDL_WINDOWPOS_UNDEFINED,
                              screen_w, screen_h,
                              0);
    if(!window) {
        snprintf(errmsg, bufsize, "Unable to get video surface.");
        goto error;
    }

    bouncing_balls(window);

    SDL_Quit();

    // Wait a little bit just in case something went wrong (so that printfs can be read)
    SDL_Delay(5000);
    
    return 0;

    // Upon an error, print message and quit properly
error:
    fprintf(stderr, "%s Error returned: %s\n", errmsg, SDL_GetError());
    SDL_Quit();
    exit(EXIT_FAILURE);
}

// Clear the surface by filling it with 0x00000000(black).
void clear_screen(SDL_Surface *surface)
{
    if(SDL_FillRect(surface, NULL, 0x00000000) < 0){
        fprintf(stderr, "Unable to clear the surface. Error returned: %s\n", SDL_GetError());
        SDL_Quit();
        exit(EXIT_FAILURE);
    }
}

// Animate bouncing balls on the screen.
void bouncing_balls(SDL_Window *window)
{
    SDL_Event event;
    SDL_Surface *surface;
    surface = SDL_GetWindowSurface(window);
    int done = 0;
    list_t *list;
    list_iterator_t *iter;
    object_t *object;
    unsigned int last_time;
    unsigned int current_time;
    int FPS = 60;
    int total_balls = 4;


    list = list_create();
    iter = list_createiterator(list);

    for(int numballs = 0; numballs < total_balls; numballs++)
    {
        object = create_object(surface, sphere_model, SPHERE_NUMTRIANGLES);
        list_addfirst(list, object);
    }

    list_resetiterator(iter);

    // the main loop to generate frames to display in the animation
    while (!done) {
        clear_screen(surface);
        last_time = SDL_GetTicks();

        for(int numballs = 0; numballs < total_balls; numballs++)
        {
            object = list_next(iter);
            if(object != NULL)
            {
                draw_object(object);
                update_object(object);

                // Calculates the speed-vector of object
                object->total_speed = sqrt(sqrt(object->speedx * object->speedx) + sqrt(object->speedy * object->speedy));

                // saves the time when object stopped
                if(object->total_speed == 0 && object->time_when_stopped == 0)
                {
                    object->time_when_stopped = SDL_GetTicks();
                }

                if(object->total_speed == 0 && object->time_when_stopped != 0)
                {
                    object->current_time_obj = SDL_GetTicks();
                    
                    // checks if the ball has been lying still for more than 5 seconds
                    if(object->current_time_obj > object->time_when_stopped + 5000)
                    {
                        destroy_object(object);
                        list_remove(list, object);
                        object = create_object(surface, sphere_model, SPHERE_NUMTRIANGLES);
                        list_addfirst(list, object);
                        list_resetiterator(iter);
                    }
                }
            }
        }
        list_resetiterator(iter);

        // Update the window surface
        SDL_UpdateWindowSurface(window);

        // Detect that the user tries to quit the application
        while(SDL_PollEvent(&event)) {
            switch(event.type) {
                case SDL_QUIT:
                    done = 1;
                    break;
                case SDL_WINDOWEVENT:
                    if (event.window.event == SDL_WINDOWEVENT_SHOWN)
                        SDL_SetWindowPosition(window, 50, 50);
                    break;
            }
        }
        
        // supresses the framerate to the specified amount
        current_time = SDL_GetTicks();
        while(current_time < last_time + (1000/FPS))
        {
            current_time = SDL_GetTicks();
        }
    }
}