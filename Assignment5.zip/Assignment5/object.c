#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <SDL.h>
#include "drawline.h"
#include "triangle.h"
#include "object.h"


// Return a newly created object based on the arguments provided.
object_t *create_object(SDL_Surface *surface, triangle_t *model, int numtriangles)
{
    object_t *object = calloc(1, sizeof(object_t));
    if(object == NULL)
        perror("Could not allocate memory for object in: create_object");

    object->model = calloc(1, sizeof(triangle_t)*numtriangles);
    if(object->model == NULL)
    {
        free(object);
        perror("Could not allocate memory for object->model in: create_object");
    }
    memcpy(object->model, model, sizeof(triangle_t)*numtriangles);
    object->scale = 0.1;
    object->rotation = 0;
    object->radius = 500 * object->scale;
    object->tx = object->radius + 2;
    object->ty = object->radius + 2;
    object->speedx = rand() % 31;
    if(object->speedx == 0)
        object->speedx = 1;
    object->speedy = rand() % 31;
    object->current_time_obj = 0;
    object->time_when_stopped = 0;
    object->total_speed = 0;
    object->numtriangles = numtriangles;
    object->surface = surface;
    return object;
}

// Destroy the object, freeing the memory.
void destroy_object(object_t *object)
{
    free(object->model);
    free(object);
}


// Draw the object on its surface.
void draw_object(object_t *object)
{
    for(int i = 0; i < object->numtriangles; i ++) {
        object->model[i].scale = object->scale;
        object->model[i].tx = object->tx;
        object->model[i].ty = object->ty;
        object->model[i].rotation = object->rotation;
        draw_triangle(object->surface, &object->model[i]); 
    }
} 

void update_object(object_t *object)
{
    object->tx = object->tx + object->speedx;
    object->ty = object->ty + object->speedy;
    object->rotation = object->rotation + 10;
    
    // calculates reduction in speed when hitting a wall
    // inverts the speed
    float gravity = 0.2;
    if(object->tx + object->radius + object->speedx >= object->surface->w)
        object->speedx = (object->speedx * 0.9) * -1;
    if(object->tx - object->radius + object->speedx <= 0)
        object->speedx = (object->speedx * 0.9) * -1;

    // if object is still bouncing
    if(object->ty + object->radius < object->surface->h)
    {
        // calculuates reduction in speed when hitting the ground (or "roof")
        // inverts the speed
        if(object->ty + object->radius + object->speedy >= object->surface->h - 2)
        {
            object->speedy = (object->speedy * 0.9) * -1;
            object->speedx = object->speedx * 0.95;
        }
        if(object->ty - object->radius + object->speedy <= 0)
        {
            object->speedy = (object->speedy * 0.9) * -1;
            object->speedx = object->speedx * 0.95;
        }
        object->speedy = object->speedy + gravity;
    }
    // if object is on the ground
    if(object->ty + object->radius >= object->surface->h - 2)
    {
        object->speedy = 0;
        object->ty = object->surface->h - object->radius - 2;

        // rolling resistance (to bring the ball to a stop)
        if(object->speedx > 0)
        {
        object->speedx = object->speedx - 0.01;
        }
        if(object->speedx < 0)
        {
        object->speedx = object->speedx + 0.01;
        }
    }
}
