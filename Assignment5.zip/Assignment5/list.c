#include <stdio.h>
#include <stdlib.h>
#include "list.h"

// List implementation

typedef struct listnode listnode_t;
typedef struct list_iterator list_iterator_t;

struct listnode {
    listnode_t  *next;
    void        *item;
};

struct list {
    listnode_t *head;
    int numitems;
};

// Returns a newly created, empty list.
list_t *list_create(void)
{
    list_t *list = malloc(sizeof(list));
    list->head = NULL;
    list->numitems = 0;
    return list;
}

// Frees the list; list and nodes, but not the items it holds.
void list_destroy(list_t *list)
{
    listnode_t *tmp_current = list->head;
    
    while(list->head != NULL)
    {
        tmp_current = list->head->next;
        free(list->head);
        list->head = tmp_current;
    }
    free(list);
}

// Adds an item first in the provided list.
void list_addfirst(list_t *list, void *item)
{
    listnode_t *node = malloc(sizeof(listnode_t));
    node->next = list->head;
    node->item = item;
    list->head = node;
    list->numitems++;
}

// Adds an item last in the provided list.
void list_addlast(list_t *list, void *item)
{
    listnode_t *tmp_current = list->head;
    
    if (list->head == NULL)
    {
        list_addfirst(list, item);
    }
    else
    {
        if(tmp_current->next == NULL)
        {
            listnode_t *node = malloc(sizeof(listnode_t));
            node->next = NULL;
            node->item = item;
            list->numitems++;
            tmp_current->next = node;
        }
        else
        {
            while(tmp_current->next != NULL)
            {
                tmp_current = tmp_current->next;
            }
            listnode_t *node = malloc(sizeof(listnode_t));
            node->next = NULL;
            node->item = item;
            list->numitems++;
            tmp_current->next = node;
        }
    }
}


// Removes an item from the provided list, only freeing the node.
void list_remove(list_t *list, void *item)
{
    listnode_t *tmp_current = list->head;
    listnode_t *tmp_next = list->head;

    tmp_next = list->head->next;
    
    if(tmp_current->item == item)
    {
        free(tmp_current);
        list->head = tmp_next;
        list->numitems--;
    }
    else
    {
        while(tmp_next->item != item)
        {
            tmp_current = tmp_next;
            tmp_next = tmp_next->next;
        }
        if(tmp_next->item == item)
        {
            tmp_current->next = tmp_next->next;
            free(tmp_next);
            list->numitems--;
        }
    }
}

// Return the number of items in the list.
int list_size(list_t *list)
{
    return list->numitems;
}


 
// Iterator implementation 

struct list_iterator {
    listnode_t *next;
    list_t *list;
    listnode_t *current;
};

// Return a newly created list iterator for the given list.
list_iterator_t *list_createiterator(list_t *list)
{
    list_iterator_t *iter = calloc(1, sizeof(iter));
    iter->list = list;
    iter->next = list->head;
    iter->current = list->head;
    return iter;
}

// Free the memory for the given list iterator.
void list_destroyiterator(list_iterator_t *iter)
{
    free(iter);
}

// Move iterator to next item in list and return current.
void *list_next(list_iterator_t *iter)
{
    if(iter == NULL || iter->next == NULL)
        return NULL;
    void *tmp = iter->next->item;
    if(iter->next != NULL)
    {
        iter->next = iter->next->next;
    }
    return tmp;
}

// Let iterator point to first item in list again.
void list_resetiterator(list_iterator_t *iter)
{
    iter->next = iter->list->head;
}
